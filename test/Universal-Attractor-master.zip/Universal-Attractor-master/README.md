# Universal Attractor
A game made by Aarex where I could beat a game with 4 prestige layers with 2 more layers.